<?php

class Conekta_WebhookLog extends Conekta_Resource
{
}
